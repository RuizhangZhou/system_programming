var struct_page_result =
[
    [ "child", "struct_page_result.html#aef6d9b33a716552010f677eb0ccad559", null ],
    [ "success", "struct_page_result.html#a26ab3f163c9b9e0ab50d0325dac0b921", null ]
];