var searchData=
[
  ['writesram_5fexternal_288',['writeSRAM_external',['../os__mem__drivers_8c.html#a6a57733985847f954d69d521c2e75e01',1,'os_mem_drivers.c']]],
  ['writesram_5finternal_289',['writeSRAM_internal',['../os__mem__drivers_8c.html#a36530bd7e06adc3f8b056b1caee1c802',1,'os_mem_drivers.c']]]
];
