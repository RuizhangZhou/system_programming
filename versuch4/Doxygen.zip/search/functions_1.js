var searchData=
[
  ['delayms_326',['delayMs',['../util_8c.html#a6203c4722e9cbe1542b6ccbe98362dd2',1,'delayMs(Time ms):&#160;util.c'],['../util_8h.html#a6203c4722e9cbe1542b6ccbe98362dd2',1,'delayMs(Time ms):&#160;util.c']]],
  ['deselect_5fmemory_327',['deselect_memory',['../os__mem__drivers_8c.html#ad0810cb41540897c98168c15dbd8a929',1,'os_mem_drivers.c']]]
];
