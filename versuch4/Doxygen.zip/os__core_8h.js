var os__core_8h =
[
    [ "os_error", "os__core_8h.html#aff56fb8e39e4b0db051157ca9b7bf57b", null ],
    [ "os_errorPStr", "os__core_8h.html#a1ed51c8da9054e49d1f14175945cc563", null ],
    [ "os_init", "os__core_8h.html#a6cc2e63d83267ff5059bf0a76b302a09", null ],
    [ "os_init_timer", "os__core_8h.html#a6e2cb65995e0266255572244baf860f3", null ],
    [ "__heap_start", "os__core_8h.html#aa1b242a8ba3e152cede356fe4e176ff6", null ]
];