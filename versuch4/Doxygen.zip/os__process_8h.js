var os__process_8h =
[
    [ "StackPointer", "union_stack_pointer.html", null ],
    [ "Process", "struct_process.html", null ],
    [ "PROGRAM", "os__process_8h.html#a93a3541223068451d44542da517becc6", null ],
    [ "Age", "os__process_8h.html#a797b124dfc6dae58ad80c58d142e5e2a", null ],
    [ "Priority", "os__process_8h.html#a1bb679f7ad1508e942e35da9a0e7eabf", null ],
    [ "Process", "os__process_8h.html#a3b5b0413545e0d4ff600b0a7203e3086", null ],
    [ "ProcessID", "os__process_8h.html#a9ae6ab2a896fd7ccf2c04cd38f9fa6c9", null ],
    [ "ProcessState", "os__process_8h.html#a188e89ad1abd0d38668fb83d89aa8891", null ],
    [ "Program", "os__process_8h.html#a1855c0ea815dd2a3323638f2fda0c38a", null ],
    [ "ProgramID", "os__process_8h.html#a1ab31056d5f9a7353e80e9718fe5698d", null ],
    [ "StackChecksum", "os__process_8h.html#a45db48aaf651fca0006e612d9a3b4b9b", null ],
    [ "StackPointer", "os__process_8h.html#a52b6ead6aa07550bf81e7340e9d50e53", null ],
    [ "OnStartDo", "os__process_8h.html#a10bb266b2caa098f6db8b75deb8c930d", null ],
    [ "ProcessState", "os__process_8h.html#a373a58178f69d5e3e1de7516d105675e", null ],
    [ "os_isRunnable", "os__process_8h.html#a08927504c714d2c1eeb4f33e71998407", null ]
];